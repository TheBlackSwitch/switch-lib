execute unless function theblackswitch:v2.0/patch-3/version_control/is_latest run return fail
execute if function theblackswitch:v2.0/patch-3/test run say hi
