execute unless function theblackswitch:v2.0/patch-4/version_control/is_latest run return fail
function #theblackswitch:v2.0/events/init_player
