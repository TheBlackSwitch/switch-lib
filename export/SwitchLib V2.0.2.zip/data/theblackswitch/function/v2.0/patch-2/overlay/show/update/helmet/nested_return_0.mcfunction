item replace entity @a[predicate=theblackswitch:v2.0/patch-2/player_id/match_search, limit=1] armor.head with air
function theblackswitch:v2.0/patch-2/overlay/show/kill_minecart
